@echo off
cd /d "%~dp0"
echo ============================================================
echo   Ticker local server  (no Apache needed)
echo   Serves:  http://localhost/ticker/ticker_control.html
echo   Data:    tools\.ticker_data  (config, news, feeds)
echo ============================================================
echo.
echo If XAMPP Apache is still running it owns port 80.
echo Stop Apache first (XAMPP Control Panel -^> Stop on Apache)
echo then press 1. Or press 2 to run on port 8800 instead.
echo.
set /p PORT_CHOICE="Run on port 80 [1]  or  8800 [2]?  "
if "%PORT_CHOICE%"=="1" set PORT=80
if "%PORT_CHOICE%"=="2" set PORT=8800
if not defined PORT set PORT=8800
echo.
python "%~dp0tools\local_cgi_server.py" --docroot "C:\xampp\htdocs\ticker" --prefix "/ticker" --port %PORT%
echo.
pause