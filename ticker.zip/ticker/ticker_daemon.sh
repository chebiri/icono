#!/system/bin/sh
# ticker_daemon.sh — periodic server-side news refresh for the HTML ticker
# Hook into the panel start.sh so it runs at boot (see deploy_ticker.sh).
# Reads feeds configured in ticker_feeds.json and pushes headlines into
# ticker_news.json (displayed by ticker.html).

CGI=/data/plugin/panel/www/cgi-bin/ticker_fetch
INTERVAL="${TICKER_INTERVAL:-600}"

for pid in $(busybox ps 2>/dev/null | grep "[t]icker_daemon" | awk '{print $1}'); do
    [ "$pid" != "$$" ] && kill -9 "$pid" 2>/dev/null
done

sleep 20

while true; do
    [ -x "$CGI" ] && QUERY_STRING="action=refresh&max=25" "$CGI" >/dev/null 2>&1
    sleep "$INTERVAL"
done