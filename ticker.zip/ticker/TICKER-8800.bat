@echo off
cd /d "%~dp0"
echo Launching ticker server on port 8800...
echo URL:  http://localhost:8800/ticker/ticker_control.html
echo.
python "%~dp0tools\local_cgi_server.py" --docroot "C:\xampp\htdocs\ticker" --prefix "/ticker" --port 8800
echo.
pause