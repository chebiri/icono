#!/usr/bin/env python3
# local_cgi_server.py — standalone CGI-capable server for the ticker pages.
# No Apache needed: this runs the cgi-bin shell CGIs directly (exactly like
# the receiver's web server does), so localhost URLs work for real.
#
# Examples
#   # serve the project's own ticker/www   -> http://127.0.0.1:8800/ticker_control.html
#   python local_cgi_server.py
#
#   # serve an existing copy (e.g. XAMPP htdocs) at the exact URL you want
#   python local_cgi_server.py --docroot C:\xampp\htdocs\ticker --prefix /ticker --port 80
#                                               -> http://localhost/ticker/ticker_control.html
#   python local_cgi_server.py --docroot C:\xampp\htdocs --prefix /ticker --port 80
#                               (docroot contains the "ticker" subfolder)

import argparse
import http.server
import os
import subprocess
import sys
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_DR = os.path.normpath(os.path.join(HERE, '..', 'www'))
DATA = os.path.join(HERE, '.ticker_data')

SHELLS = [
    os.environ.get('TICKER_SH', ''),
    r'C:\Program Files\Git\bin\sh.exe',
    r'C:\Program Files\Git\usr\bin\sh.exe',
    r'C:\Windows\System32\bash.exe',
    'sh',
]

MIME = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.png': 'image/png',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon',
    '.txt': 'text/plain; charset=utf-8',
}


def find_shell():
    for p in SHELLS:
        if p and os.path.exists(p):
            return p
    return 'sh'


def ensure_data():
    os.makedirs(DATA, exist_ok=True)
    seeds = {
        'ticker.json': '{"enabled":true,"position":"bottom","height":44,"speed":60,"font_size":22,"color":"#FFFFFF","bg":"#000000","bg_alpha":140,"border":"#FFB300","border_width":0,"interval":12,"direction":"rtl","separator":"   \\u25C6   ","show_source":true}',
        'ticker_news.json': '{"items":[{"text":"\\u0627\\u062e\\u062a\\u0628\\u0627\\u0631 \\u0627\\u0644\\u0634\\u0631\\u064a\\u0637","source":"Icono","time":"00:00"}]}',
        'ticker_feeds.json': '{"feeds":["https://news.google.com/rss?hl=ar&gl=EG&ceid=EG:ar"]}',
    }
    for name, content in seeds.items():
        path = os.path.join(DATA, name)
        if not os.path.exists(path):
            with open(path, 'w', encoding='utf-8') as f:
                f.write(content)
    return find_shell()


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = 'TickerLocal/1.0'
    docroot = None
    prefix = ''

    def log_message(self, fmt, *args):
        pass

    def _resolve(self, path):
        if path.startswith(self.prefix):
            path = path[len(self.prefix):] or '/'
        path = urllib.parse.unquote(path)
        if path == '/' or path == '':
            path = '/ticker_control.html'
        return path

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = self._resolve(parsed.path)
        query = parsed.query

        if path.startswith('/cgi-bin/'):
            self._run_cgi(path[len('/cgi-bin/'):], query)
            return

        fs = os.path.normpath(os.path.join(self.docroot, path.lstrip('/')))
        if not fs.startswith(self.docroot):
            self.send_error(403)
            return
        if not os.path.isfile(fs):
            self.send_error(404)
            return
        ext = os.path.splitext(fs)[1].lower()
        with open(fs, 'rb') as fh:
            body = fh.read()
        self.send_response(200)
        self.send_header('Content-Type', MIME.get(ext, 'application/octet-stream'))
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def _run_cgi(self, name, query):
        script = os.path.normpath(os.path.join(self.docroot, 'cgi-bin', name))
        if not os.path.isfile(script):
            self.send_error(404)
            return
        env = dict(os.environ)
        env['QUERY_STRING'] = query
        env['REQUEST_METHOD'] = 'GET'
        env['REMOTE_ADDR'] = self.client_address[0]
        env['SCRIPT_NAME'] = '/cgi-bin/' + name
        env['TICKER_CONF'] = os.path.join(DATA, 'ticker.json')
        env['TICKER_NEWS'] = os.path.join(DATA, 'ticker_news.json')
        env['TICKER_FEEDS'] = os.path.join(DATA, 'ticker_feeds.json')
        cwd = os.path.dirname(script)
        try:
            proc = subprocess.run([SHELL, script], cwd=cwd, env=env,
                                  capture_output=True, timeout=60)
        except subprocess.TimeoutExpired:
            self.send_error(504)
            return
        out = proc.stdout
        if proc.returncode != 0 and not out:
            out = proc.stderr or b'cgi failed'
        text = out.decode('utf-8', 'replace')
        head, _, body = text.partition('\n\n')
        lines = head.splitlines()
        ctype = 'application/json'
        for ln in lines:
            low = ln.lower()
            if low.startswith('content-type'):
                ctype = ln.split(':', 1)[1].strip()
        self.send_response(200)
        self.send_header('Content-Type', ctype)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Cache-Control', 'no-store')
        body_bytes = body.encode('utf-8') if body else b''
        self.send_header('Content-Length', str(len(body_bytes)))
        self.end_headers()
        self.wfile.write(body_bytes)


def main():
    ap = argparse.ArgumentParser(description='Ticker local CGI server')
    ap.add_argument('--docroot', default=DEFAULT_DR,
                    help='folder that contains ticker.html + cgi-bin/')
    ap.add_argument('--prefix', default='',
                    help='URL prefix, e.g. /ticker  (paths already starting with prefix are stripped)')
    ap.add_argument('--port', type=int, default=8800)
    args = ap.parse_args()

    global SHELL
    SHELL = ensure_data()
    docroot = os.path.abspath(args.docroot)
    if not os.path.isdir(docroot):
        print('docroot not found:', docroot)
        sys.exit(1)

    Handler.docroot = docroot
    Handler.prefix = args.prefix.rstrip('/')

    url = 'http://localhost' if args.port == 80 else f'http://127.0.0.1:{args.port}'
    url += args.prefix + '/ticker_control.html'
    try:
        server = http.server.ThreadingHTTPServer(('0.0.0.0', args.port), Handler)
    except OSError as e:
        print('Could not bind port', args.port, '->', e)
        print('Port 80 is usually taken by Apache/XAMPP; stop it or use --port 8800')
        sys.exit(1)

    print('Serving:', docroot)
    print('Open   :', url)
    print('Shell  :', SHELL)
    print('Ctrl+C to stop')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.shutdown()


if __name__ == '__main__':
    main()