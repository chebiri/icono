#!/system/bin/sh
# deploy_ticker.sh — installs the HTML news ticker into the Icono panel
# Run from a shell on the receiver (or busybox sh).
# Place this script + the www/ folder on the box first.

PANEL_WWW="/data/plugin/panel/www"
PANEL_CGI="$PANEL_WWW/cgi-bin"

echo "Deploying News Ticker (HTML) ..."

mkdir -p "$PANEL_WWW" "$PANEL_CGI"

# keep config/news persistence across re-deploys
if [ ! -f "$PANEL_WWW/ticker.json" ]; then
    cp -f ./ticker.json "$PANEL_WWW/ticker.json" 2>/dev/null
fi
if [ ! -f "$PANEL_WWW/ticker_news.json" ]; then
    cp -f ./ticker_news.json "$PANEL_WWW/ticker_news.json" 2>/dev/null
fi

cp -f ./ticker.html "$PANEL_WWW/ticker.html" 2>/dev/null
cp -f ./ticker_control.html "$PANEL_WWW/ticker_control.html" 2>/dev/null
if [ ! -f "$PANEL_WWW/ticker_feeds.json" ]; then
    cp -f ./ticker_feeds.json "$PANEL_WWW/ticker_feeds.json" 2>/dev/null
fi

cp -f ./ticker_config "$PANEL_CGI/ticker_config" 2>/dev/null
cp -f ./ticker_data "$PANEL_CGI/ticker_data" 2>/dev/null
cp -f ./ticker_fetch "$PANEL_CGI/ticker_fetch" 2>/dev/null
[ -f ./ticker_daemon.sh ] && cp -f ./ticker_daemon.sh /data/plugin/subsync/ticker_daemon.sh 2>/dev/null

chmod 755 "$PANEL_CGI/ticker_config" "$PANEL_CGI/ticker_data" "$PANEL_CGI/ticker_fetch" 2>/dev/null
chmod 755 /data/plugin/subsync/ticker_daemon.sh 2>/dev/null
chmod 644 "$PANEL_WWW/ticker.html" "$PANEL_WWW/ticker_control.html" \
         "$PANEL_WWW/ticker.json" "$PANEL_WWW/ticker_news.json" "$PANEL_WWW/ticker_feeds.json" 2>/dev/null

# boot persistence for the news daemon
sed -i '/ticker_daemon/d' /data/plugin/panel/start.sh 2>/dev/null
sed -i '/start_httpd/a \  [ -x /data/plugin/subsync/ticker_daemon.sh ] && /data/plugin/subsync/ticker_daemon.sh >/dev/null 2>&1 &' /data/plugin/panel/start.sh 2>/dev/null
chmod 755 /data/plugin/panel/start.sh 2>/dev/null

echo "Done. Open:"
echo "  Control  -> http://<box>/ticker_control.html"
echo "  Ticker   -> http://<box>/ticker.html   (fullscreen overlay)"
echo "  API get  -> http://<box>/cgi-bin/ticker_config?action=get"
echo "  API push -> http://<box>/cgi-bin/ticker_data?action=push&text=Hello&source=Icono"
echo "  RSS now  -> http://<box>/cgi-bin/ticker_fetch?action=refresh"

sync