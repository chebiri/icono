#!/system/bin/sh
export PATH=/system/bin:/system/xbin:/vendor/bin:/sbin:$PATH

# Kill older instances of this script to prevent duplicate processes
for pid in $(busybox ps 2>/dev/null | grep "[a]uto_poster.sh" | awk '{print $1}'); do
    [ "$pid" != "$$" ] && kill -9 "$pid" 2>/dev/null
done

API_KEY="trilogy"
LAST_SVC=""
CONF="/data/plugin/panel/overlay.conf"

sleep 15

while true; do
    if [ -f /tmp/cursvc.tmp ]; then
        SVC_ID=$(busybox hexdump -s 20 -n 2 -e '1/2 "%u"' /tmp/cursvc.tmp 2>/dev/null)
        
        if [ "$SVC_ID" != "$LAST_SVC" ] && [ -n "$SVC_ID" ] && [ "$SVC_ID" != "0" ]; then
            LAST_SVC="$SVC_ID"
            sleep 4
            
            CUR_SVC=$(busybox hexdump -s 20 -n 2 -e '1/2 "%u"' /tmp/cursvc.tmp 2>/dev/null)
            if [ "$CUR_SVC" = "$SVC_ID" ]; then
            
            JSON=$(/data/plugin/subsync/autodetect_movie.sh 2>/dev/null)
            TITLE=$(echo "$JSON" | sed -n 's/.*"movie": "\([^"]*\)".*/\1/p')
            CH_NAME=$(echo "$JSON" | sed -n 's/.*"channel": "\([^"]*\)".*/\1/p')
            DESC=$(echo "$JSON" | sed -n 's/.*"desc": "\([^"]*\)".*/\1/p')
            
            if [ -n "$TITLE" ] && [ "$TITLE" != "بدون معلومات EPG" ]; then
                if echo "$TITLE" | grep -qE "[أ-ي]"; then
                    URL_ENC_TITLE=$(echo -n "$TITLE" | busybox hexdump -v -e '/1 "X%02X"' | sed 's/X/%/g')
                    TRANS_JSON=$(curl -s "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=en&dt=t&q=$URL_ENC_TITLE" 2>/dev/null)
                    EN_TITLE=$(echo "$TRANS_JSON" | cut -d '"' -f 2)
                    [ -n "$EN_TITLE" ] && TITLE="$EN_TITLE"
                fi
                
                SAFE_TITLE=$(echo "$TITLE" | tr ' ' '+')
                URL="http://www.omdbapi.com/?t=${SAFE_TITLE}&apikey=${API_KEY}"
                OMDB=$(curl -s --connect-timeout 4 -m 4 "$URL" 2>/dev/null)
                RESPONSE=$(echo "$OMDB" | sed -n 's/.*"Response":"\([^"]*\)".*/\1/p')
                
                if [ "$RESPONSE" = "True" ]; then
                    POSTER=$(echo "$OMDB" | sed -n 's/.*"Poster":"\([^"]*\)".*/\1/p' | sed 's/\\//g')
                    YEAR=$(echo "$OMDB" | sed -n 's/.*"Year":"\([^"]*\)".*/\1/p' | sed 's/\\//g')
                    PLOT=$(echo "$OMDB" | sed -n 's/.*"Plot":"\([^"]*\)".*/\1/p' | sed 's/\\//g')
                    RATING=$(echo "$OMDB" | sed -n 's/.*"imdbRating":"\([^"]*\)".*/\1/p' | sed 's/\\//g')
                    GENRE=$(echo "$OMDB" | sed -n 's/.*"Genre":"\([^"]*\)".*/\1/p' | sed 's/\\//g')
                    
                    if [ -n "$POSTER" ] && [ "$POSTER" != "N/A" ]; then
                        TRANSLATE_ARABIC=$(grep "TRANSLATE_ARABIC" "$CONF" 2>/dev/null | cut -d'=' -f2)
                        if [ "$TRANSLATE_ARABIC" = "1" ] && [ -n "$PLOT" ] && [ "$PLOT" != "N/A" ]; then
                            URL_ENC_PLOT=$(echo -n "$PLOT" | busybox hexdump -v -e '/1 "X%02X"' | sed 's/X/%/g')
                            TRANS_PLOT_JSON=$(curl -s "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ar&dt=t&q=$URL_ENC_PLOT" 2>/dev/null)
                            AR_PLOT=$(echo "$TRANS_PLOT_JSON" | sed 's/],\[/\n/g' | cut -d '"' -f 2 | grep -E "[أ-ي]" | tr '\n' ' ' | sed 's/ $//')
                            [ -n "$AR_PLOT" ] && PLOT="$AR_PLOT"
                        fi
                        
                        /data/plugin/subsync/subsync.sh movie_card "$TITLE" "$POSTER" "$YEAR" "$RATING" "$GENRE" "" "$PLOT" "8" "top-right" "" >/dev/null 2>&1
                    fi
                fi
            fi
            fi
        fi
    fi
    sleep 2
done
