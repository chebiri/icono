TR_OCTALS="\001\002\003\004\005\006\007\010\013\014\016\017\020\021\022\023\024\025\026\027\030\031\032\033\034\035\036\037"
#!/system/bin/sh
export PATH=/system/bin:/system/xbin:/vendor/bin:/sbin:$PATH
DIR="/data/plugin/subsync"
SQLITE="$DIR/sqlite3"

# 1. Read svc_id, svc_idx, ts_id from /tmp/cursvc.tmp
SVC_ID=0
SVC_IDX=0
TS_ID=0

if [ -f /tmp/cursvc.tmp ]; then
    SVC_ID=$(busybox hexdump -s 20 -n 2 -e '1/2 "%u"' /tmp/cursvc.tmp 2>/dev/null)
    SVC_IDX=$(busybox hexdump -s 8 -n 2 -e '1/2 "%u"' /tmp/cursvc.tmp 2>/dev/null)
    TS_ID=$(busybox hexdump -s 18 -n 2 -e '1/2 "%u"' /tmp/cursvc.tmp 2>/dev/null)
fi

[ -z "$SVC_ID" ] && SVC_ID=0
[ -z "$SVC_IDX" ] && SVC_IDX=0
[ -z "$TS_ID" ] && TS_ID=0

# 2. Get Channel Name from service.db
CH_NAME=""
if [ "$SVC_IDX" -gt 0 ] && [ -x "$SQLITE" ] && [ -f /data/db/service.db ]; then
    CH_NAME=$($SQLITE "file:/data/db/service.db?immutable=1" "SELECT CASE WHEN unicode(substr(svc_name, 1, 1)) < 32 THEN substr(svc_name, 2) ELSE svc_name END FROM _svcInfo WHERE svc_idx=$SVC_IDX LIMIT 1;" 2>/dev/null | tr -d '\r\n')
fi
[ -z "$CH_NAME" ] && CH_NAME="Channel_$SVC_ID"

# 3. Query EPG for current running event and calculate exact elapsed time
MOVIE_TITLE="بدون معلومات EPG"
MOVIE_YEAR=""
MOVIE_DESC=""
START_TIME=""
END_TIME=""
DUR_MIN=0
ELAPSED_SEC=0
ELAPSED_MIN=0
REM_MIN=0
PROGRESS_PCT=0

if [ "$SVC_ID" -gt 0 ] && [ -x "$SQLITE" ] && [ -f /data/db/epg.db ]; then
    SQL_CURRENT="
    WITH cur AS (
        SELECT 
            CAST(julianday('now') - 2400000.5 AS INT) * 1440 + 
            CAST(strftime('%H', 'now') AS INT) * 60 + 
            CAST(strftime('%M', 'now') AS INT) AS cur_mins,
            CAST(strftime('%S', 'now') AS INT) AS cur_secs
    ),
    evts AS (
        SELECT 
            id,
            (CASE WHEN unicode(substr(event_name, 1, 1)) < 32 THEN substr(event_name, 2) ELSE event_name END) AS event_name,
            (CASE WHEN unicode(substr(COALESCE(event_extended_text, ''), 1, 1)) < 32 THEN substr(COALESCE(event_extended_text, ''), 2) ELSE COALESCE(event_extended_text, '') END) AS event_extended_text,
            ((event_start_time >> 16) & 65535) * 1440 + 
            ((event_start_time >> 8) & 255) * 60 + 
            (event_start_time & 255) AS st_mins,
            ((event_duration >> 8) & 255) * 60 + 
            (event_duration & 255) AS dur_mins,
            printf('%02d:%02d', (event_start_time >> 8) & 255, event_start_time & 255) AS st_time,
            printf('%02d:%02d', (event_end_time >> 8) & 255, event_end_time & 255) AS et_time
        FROM _eventData
        WHERE event_svc_id = $SVC_ID
    )
    SELECT 
        event_name || char(9) ||
        st_time || char(9) ||
        et_time || char(9) ||
        dur_mins || char(9) ||
        (cur.cur_mins - evts.st_mins) || char(9) ||
        ((cur.cur_mins - evts.st_mins) * 60 + cur.cur_secs) || char(9) ||
        (evts.dur_mins - (cur.cur_mins - evts.st_mins)) || char(9) ||
        CAST((cur.cur_mins - evts.st_mins) * 100.0 / evts.dur_mins AS INT) || char(9) ||
        COALESCE(event_extended_text, '')
    FROM evts, cur
    WHERE cur.cur_mins >= evts.st_mins AND cur.cur_mins < (evts.st_mins + evts.dur_mins)
    LIMIT 1;
    "

    RES=$($SQLITE "file:/data/db/epg.db?immutable=1" "$SQL_CURRENT" 2>/dev/null | head -n 1)
    
    # Fallback if no exact match: get latest event for this channel
    if [ -z "$RES" ]; then
        SQL_LATEST="
        SELECT 
            event_name || char(9) ||
            printf('%02d:%02d', (event_start_time >> 8) & 255, event_start_time & 255) || char(9) ||
            printf('%02d:%02d', (event_end_time >> 8) & 255, event_end_time & 255) || char(9) ||
            (((event_duration >> 8) & 255) * 60 + (event_duration & 255)) || char(9) ||
            '0' || char(9) || '0' || char(9) ||
            (((event_duration >> 8) & 255) * 60 + (event_duration & 255)) || char(9) || '0' || char(9) ||
            COALESCE(event_extended_text, '')
        FROM _eventData
        WHERE event_svc_id = $SVC_ID
        ORDER BY id DESC
        LIMIT 1;
        "
        RES=$($SQLITE "file:/data/db/epg.db?immutable=1" "$SQL_LATEST" 2>/dev/null | head -n 1)
    fi

    if [ -n "$RES" ]; then
        TAB="$(printf '\t')"
        MOVIE_TITLE=$(echo "$RES" | cut -d"$TAB" -f1)
        START_TIME=$(echo "$RES" | cut -d"$TAB" -f2)
        END_TIME=$(echo "$RES" | cut -d"$TAB" -f3)
        DUR_MIN=$(echo "$RES" | cut -d"$TAB" -f4)
        ELAPSED_MIN=$(echo "$RES" | cut -d"$TAB" -f5)
        ELAPSED_SEC=$(echo "$RES" | cut -d"$TAB" -f6)
        REM_MIN=$(echo "$RES" | cut -d"$TAB" -f7)
        PROGRESS_PCT=$(echo "$RES" | cut -d"$TAB" -f8)
        MOVIE_DESC=$(echo "$RES" | cut -d"$TAB" -f9)
        
        # Parse 4-digit release year if present
        MOVIE_YEAR=$(echo "$MOVIE_DESC" | busybox grep -oE '\b(19[5-9][0-9]|20[0-2][0-9])\b' 2>/dev/null | head -n 1)
        [ -z "$MOVIE_YEAR" ] && MOVIE_YEAR=$(echo "$MOVIE_TITLE" | busybox grep -oE '\b(19[5-9][0-9]|20[0-2][0-9])\b' 2>/dev/null | head -n 1)
    fi
fi

[ -z "$DUR_MIN" ] && DUR_MIN=0
[ -z "$ELAPSED_MIN" ] && ELAPSED_MIN=0
[ -z "$ELAPSED_SEC" ] && ELAPSED_SEC=0
[ -z "$REM_MIN" ] && REM_MIN=0
[ -z "$PROGRESS_PCT" ] && PROGRESS_PCT=0

# Ensure non-negative numbers
[ "$ELAPSED_SEC" -lt 0 ] 2>/dev/null && ELAPSED_SEC=0
[ "$ELAPSED_MIN" -lt 0 ] 2>/dev/null && ELAPSED_MIN=0
[ "$REM_MIN" -lt 0 ] 2>/dev/null && REM_MIN=0
[ "$PROGRESS_PCT" -lt 0 ] 2>/dev/null && PROGRESS_PCT=0
[ "$PROGRESS_PCT" -gt 100 ] 2>/dev/null && PROGRESS_PCT=100

# 4. Check if subtitle file exists for channel
HAS_SUB="false"
if [ -f "$DIR/channels/ch_${SVC_ID}_${TS_ID}.srt" ] && [ -s "$DIR/channels/ch_${SVC_ID}_${TS_ID}.srt" ]; then
    HAS_SUB="true"
elif [ -f "$DIR/current.srt" ] && [ -s "$DIR/current.srt" ]; then
    HAS_SUB="true"
elif [ -f "$DIR/current_movie.srt" ] && [ -s "$DIR/current_movie.srt" ]; then
    HAS_SUB="true"
fi

# Escape JSON strings
clean_json_str() {
    printf '%s' "$1" | busybox tr -d '\001\002\003\004\005\006\007\010\013\014\016\017\020\021\022\023\024\025\026\027\030\031\032\033\034\035\036\037' | busybox sed 's/\\/\\\\/g; s/"/\\"/g' | tr -d '\r\n'
}

SAFE_CH=$(clean_json_str "$CH_NAME")
SAFE_TITLE=$(clean_json_str "$MOVIE_TITLE")
SAFE_DESC=$(clean_json_str "$MOVIE_DESC")

cat <<EOF
{
  "status": "ok",
  "channel": "$SAFE_CH",
  "svc_id": $SVC_ID,
  "svc_idx": $SVC_IDX,
  "ts_id": $TS_ID,
  "ch_key": "ch_${SVC_ID}_${TS_ID}",
  "movie": "$SAFE_TITLE",
  "year": "${MOVIE_YEAR:-}",
  "desc": "$SAFE_DESC",
  "start_time": "$START_TIME",
  "end_time": "$END_TIME",
  "duration_min": $DUR_MIN,
  "elapsed_sec": $ELAPSED_SEC,
  "elapsed_min": $ELAPSED_MIN,
  "remaining_min": $REM_MIN,
  "progress_pct": $PROGRESS_PCT,
  "subtitle_available": $HAS_SUB
}
EOF
