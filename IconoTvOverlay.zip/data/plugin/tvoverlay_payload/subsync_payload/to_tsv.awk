function to_sec(t, a) {
    split(t, a, /[:,]/);
    return a[1]*3600 + a[2]*60 + a[3] + a[4]/1000.0;
}
BEGIN {
    FS = "
"; RS = "";
}
{
    time_line = "";
    txt = "";
    for (i = 1; i <= NF; i++) {
        if ( ~ /-->/) {
            time_line = ;
            for (j = i + 1; j <= NF; j++) {
                sub(/
$/, "", );
                if ( ~ /^[ ]*$/) continue;
                if (txt != "") txt = txt "
" ;
                else txt = ;
            }
            break;
        }
    }
    if (time_line != "" && txt != "") {
        split(time_line, parts, /[ ]+/);
        s_sec = to_sec(parts[1]);
        e_sec = to_sec(parts[3]);
        dur_ms = int((e_sec - s_sec) * 1000);
        
        # Write to tmp and base64
        print txt > "/tmp/one_sub.tmp";
        close("/tmp/one_sub.tmp");
        
        cmd = "busybox base64 < /tmp/one_sub.tmp | busybox tr -d '
'";
        cmd | getline b64;
        close(cmd);
        
        printf "%.3f%d%s
", s_sec, dur_ms, b64;
    }
}
