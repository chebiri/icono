#!/system/bin/sh
# IconoTvOverlay Automated Installer

echo "1. Installing Android APK..."
pm install -r /data/plugin/tvoverlay_payload/IconoTvOverlay.apk 2>/dev/null || pm install -r /data/plugin/tvoverlay_payload/*/IconoTvOverlay.apk 2>/dev/null

echo "2. Deploying Web Endpoints & Logo to Panel..."
mkdir -p /data/plugin/panel/www/cgi-bin /tmp/www/cgi-bin /data/plugin/subsync/channels 2>/dev/null
cp -f /data/plugin/tvoverlay_payload/overlay_config /data/plugin/panel/www/cgi-bin/ 2>/dev/null
cp -f /data/plugin/tvoverlay_payload/notify /data/plugin/panel/www/cgi-bin/ 2>/dev/null
cp -f /data/plugin/tvoverlay_payload/notify_history /data/plugin/panel/www/cgi-bin/ 2>/dev/null
cp -f /data/plugin/tvoverlay_payload/signal /data/plugin/panel/www/cgi-bin/ 2>/dev/null
cp -f /data/plugin/tvoverlay_payload/overlay.html /data/plugin/panel/www/ 2>/dev/null
cp -f /data/plugin/tvoverlay_payload/logo.png /data/plugin/panel/logo.png 2>/dev/null
cp -f /data/plugin/tvoverlay_payload/subsync /data/plugin/panel/www/cgi-bin/ 2>/dev/null
cp -f /data/plugin/tvoverlay_payload/subsync /tmp/www/cgi-bin/ 2>/dev/null
[ -f /data/plugin/tvoverlay_payload/record_ctrl ] && cp -f /data/plugin/tvoverlay_payload/record_ctrl /data/plugin/panel/www/cgi-bin/ 2>/dev/null && cp -f /data/plugin/tvoverlay_payload/record_ctrl /tmp/www/cgi-bin/ 2>/dev/null
[ -f /data/plugin/tvoverlay_payload/auto_poster.sh ] && cp -f /data/plugin/tvoverlay_payload/auto_poster.sh /data/plugin/subsync/ 2>/dev/null
rm -f /data/plugin/subsync/weather_widget.sh /data/plugin/subsync/live_ticker.sh
[ -d /data/plugin/tvoverlay_payload/subsync_payload ] && cp -rf /data/plugin/tvoverlay_payload/subsync_payload/* /data/plugin/subsync/ 2>/dev/null; chmod -R 777 /data/plugin/subsync 2>/dev/null
chmod 755 /data/plugin/panel/www/cgi-bin/* /tmp/www/cgi-bin/* 2>/dev/null
chmod 644 /data/plugin/panel/www/*.html 2>/dev/null
chmod 777 /data/plugin/panel/logo.png 2>/dev/null

echo "3. Hook into panel start.sh for boot persistence..."
sed -i '/overlay_config/d' /data/plugin/panel/start.sh 2>/dev/null
sed -i '/auto_poster/d' /data/plugin/panel/start.sh 2>/dev/null
sed -i '/weather_widget/d' /data/plugin/panel/start.sh 2>/dev/null
sed -i '/live_ticker/d' /data/plugin/panel/start.sh 2>/dev/null
sed -i '/start_httpd/a \  [ -x /data/plugin/panel/www/cgi-bin/overlay_config ] && /data/plugin/panel/www/cgi-bin/overlay_config >/dev/null 2>&1 &' /data/plugin/panel/start.sh 2>/dev/null
sed -i '/start_httpd/a \  [ -x /data/plugin/subsync/auto_poster.sh ] && /data/plugin/subsync/auto_poster.sh >/dev/null 2>&1 &' /data/plugin/panel/start.sh 2>/dev/null
chmod 755 /data/plugin/panel/start.sh 2>/dev/null

echo "4. Start overlay service now..."
busybox pkill -f "auto_poster.sh" 2>/dev/null
busybox pkill -f "weather_widget.sh" 2>/dev/null
busybox pkill -f "live_ticker.sh" 2>/dev/null
/data/plugin/panel/www/cgi-bin/overlay_config >/dev/null 2>&1 &
/data/plugin/subsync/auto_poster.sh >/dev/null 2>&1 &

echo "5. Wipe all installer files from /data/plugin..."
rm -f /data/plugin/IconoTvOverlay* /data/plugin/IconoTvOverlay.zip
rm -rf /data/plugin/tvoverlay_payload /data/plugin/data 2>/dev/null
sed -i '/IconoTvOverlay/d' /data/plugin/autorun.sh 2>/dev/null

echo "Installation Complete!"
sync
