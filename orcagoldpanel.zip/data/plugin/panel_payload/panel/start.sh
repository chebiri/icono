#!/system/bin/sh
# ============================================================================
# Démarre le daemon PANEL (busybox httpd) + AUTO-RÉPARATION de l'autorun.
# autorun.sh est un fichier sensible : un plugin USB tiers ou un client root peut
# l'écraser/l'éditer et faire disparaître la ligne qui lance le panel au boot.
# Parades :
#   1) à chaque démarrage on RÉINSÈRE la ligne panel dans autorun.sh si absente
#      (backup + sans doublon, insérée AVANT OrcaGold qui bloque) ;
#   2) un WATCHDOG détaché re-vérifie périodiquement (autorun + httpd vivant),
#      de sorte qu'une édition d'autorun est soignée AVANT le prochain reboot.
# Modes : (défaut) heal + httpd + watchdog ; « --tick » (watchdog) heal + httpd.
# Idempotent. Compatible Android 7 / busybox ash.
# ============================================================================
# PATH complet : quand le daemon est lance par le LAUNCHER (Home.onCreate), il
# herite d'un env minimal -> les CGI (getprop/dumpsys) sortent du JSON vide.
# On force un PATH systeme, herite par httpd et donc par les CGI.
export PATH=/system/bin:/system/xbin:/vendor/bin:/sbin:$PATH
DIR=/data/plugin/panel
AR=/data/plugin/autorun.sh
PANEL_LINE='[ -x /data/plugin/panel/start.sh ] && /system/bin/sh /data/plugin/panel/start.sh'
PORT=$(sed -n 's/^port=//p' "$DIR/panel.conf" 2>/dev/null); [ -z "$PORT" ] && PORT=8890

heal_autorun(){
  [ -f "$AR" ] || return 0
  grep -q 'panel/start.sh' "$AR" 2>/dev/null && return 0   # ligne déjà présente
  [ -f "$AR.bak_panelheal" ] || cp -f "$AR" "$AR.bak_panelheal" 2>/dev/null
  TMP="$AR.tmp.$$"; : > "$TMP"; INS=0
  while IFS= read -r l; do
    case "$l" in
      /data/plugin/OrcaGold*)   # ligne de commande OrcaGold (pas un commentaire)
        [ "$INS" = 0 ] && { printf '%s\n' "$PANEL_LINE" >> "$TMP"; INS=1; } ;;
    esac
    printf '%s\n' "$l" >> "$TMP"
  done < "$AR"
  [ "$INS" = 0 ] && printf '%s\n' "$PANEL_LINE" >> "$TMP"   # pas d'OrcaGold -> à la fin
  # remplacement atomique seulement si le TMP est cohérent (non vide)
  [ -s "$TMP" ] && cp -f "$TMP" "$AR" && chmod 755 "$AR"
  rm -f "$TMP"
}

am_root(){ [ "$(id -u 2>/dev/null)" = "0" ]; }

# pid du process qui ecoute :$PORT (busybox httpd), ou vide.
listener_pid(){
  busybox netstat -ltnp 2>/dev/null | busybox grep ":$PORT " \
    | busybox grep -oE '[0-9]+/busybox' | busybox grep -oE '^[0-9]+' | head -1
}
# uid reel d'un pid via /proc (1er champ de la ligne Uid:), ou vide.
proc_uid(){
  busybox grep -m1 '^Uid:' "/proc/$1/status" 2>/dev/null \
    | sed -n 's/^Uid:[^0-9]*\([0-9][0-9]*\).*/\1/p'
}

# ROOT-TAKEOVER — le daemon DOIT tourner en root (sinon /data/plugin/panel/tmp
# 700-root non inscriptible -> download KO, et install.sh /system -> KO).
# f_server execute autorun.sh en ROOT a chaque boot : cette passe root reprend
# TOUJOURS la main, meme si le launcher (uid system) a binde :$PORT en premier.
#  - lance en root  : si le listener actuel n'est PAS root, on le tue et on rebind ;
#                     s'il est deja root, on ne touche a rien (pas de churn watchdog).
#  - lance non-root : on ne deplace JAMAIS un listener existant (backup only).
start_httpd(){
  P=$(listener_pid)
  if [ -n "$P" ]; then
    if am_root; then
      U=$(proc_uid "$P")
      [ "$U" = "0" ] && return 0        # deja servi en root -> ne rien faire
      kill "$P" 2>/dev/null; sleep 1     # httpd non-root (system) -> on l'evince
      P2=$(listener_pid); [ -n "$P2" ] && { kill -9 "$P2" 2>/dev/null; sleep 1; }
    else
      return 0                           # non-root : jamais deplacer (root gagne)
    fi
  fi
  chmod -R 755 "$DIR/www/cgi-bin" 2>/dev/null
  busybox httpd -p "$PORT" -h "$DIR/www"
}

# --- watchdog (mode par défaut uniquement) ---
if [ "$1" = "--tick" ]; then
  heal_autorun; start_httpd; exit 0
fi

heal_autorun
start_httpd
echo "PANEL httpd sur $PORT"

# lance le watchdog s'il n'est pas déjà actif (verrou pid)
WD=$DIR/.watchdog.pid
if [ -f "$WD" ] && kill -0 "$(cat "$WD" 2>/dev/null)" 2>/dev/null; then
  : # watchdog déjà en cours
else
  if command -v setsid >/dev/null 2>&1; then
    setsid /system/bin/sh -c 'while :; do sleep 300; /system/bin/sh /data/plugin/panel/start.sh --tick; done' >/dev/null 2>&1 &
  else
    ( while :; do sleep 300; /system/bin/sh /data/plugin/panel/start.sh --tick; done ) >/dev/null 2>&1 &
  fi
  echo $! > "$WD"
fi

(sleep 5; /data/plugin/panel/check_update.sh) &
