#!/system/bin/sh
export PATH=/system/bin:/system/xbin:/vendor/bin:/sbin:$PATH

CONF_FILE="/data/plugin/panel/.system_alerts"
LAST_FILE="/data/plugin/panel/.last_update_alert"
PANEL_DIR="/data/plugin/panel"

# 1. Check if user disabled system alerts
if [ -f "$CONF_FILE" ] && grep -q "disabled" "$CONF_FILE"; then
    exit 0
fi

# 2. Check cooldown (at least 3600s / 1 hour between alerts, unless --force)
NOW=$(date +%s)
if [ -f "$LAST_FILE" ] && [ "$1" != "--force" ]; then
    LAST=$(cat "$LAST_FILE" 2>/dev/null || echo 0)
    DIFF=$((NOW - LAST))
    if [ "$DIFF" -lt 3600 ]; then
        exit 0
    fi
fi

# 3. Fetch live catalog (timeout 5s)
CATALOG_RAW=$(curl -s -m 5 http://127.0.0.1:8890/cgi-bin/catalog 2>/dev/null)
if [ -z "$CATALOG_RAW" ] && [ -f "$PANEL_DIR/catalog.json" ]; then
    CATALOG_RAW=$(cat "$PANEL_DIR/catalog.json" 2>/dev/null)
fi

[ -z "$CATALOG_RAW" ] && exit 0

# Helper to inspect an item and alert
check_and_notify() {
    PKG_ID="$1"
    PKG_TITLE="$2"
    
    # Extract remote version cleanly
    REMOTE_VER=$(echo "$CATALOG_RAW" | grep -A 4 "\"id\": *\"$PKG_ID\"" | grep '"version"' | sed 's/.*"version": *"\([^"]*\)".*/\1/' | tr -d ' \r\n' | head -n 1)
    [ -z "$REMOTE_VER" ] && return 0
    
    INSTALLED_VER=""
    
    if [ "$PKG_ID" = "panel-update" ]; then
        [ -f "$PANEL_DIR/www/VERSION" ] && INSTALLED_VER=$(cat "$PANEL_DIR/www/VERSION" | tr -d ' \r\n')
        [ -z "$INSTALLED_VER" ] && [ -f "$PANEL_DIR/.ver_panel-update" ] && INSTALLED_VER=$(cat "$PANEL_DIR/.ver_panel-update" | tr -d ' \r\n')
    elif [ "$PKG_ID" = "orcagold" ]; then
        [ -f "$PANEL_DIR/.ver_orcagold" ] && INSTALLED_VER=$(cat "$PANEL_DIR/.ver_orcagold" | tr -d ' \r\n')
        [ -z "$INSTALLED_VER" ] && [ -f "/data/plugin/OrcaGold.version" ] && INSTALLED_VER=$(cat "/data/plugin/OrcaGold.version" | tr -d ' \r\n')
    elif [ "$PKG_ID" = "mytvonline" ]; then
        if [ -f "$PANEL_DIR/.ver_mytvonline" ]; then
            INSTALLED_VER=$(cat "$PANEL_DIR/.ver_mytvonline" | tr -d ' \r\n')
        else
            DUMP_VER=$(dumpsys package com.siptv.mytv 2>/dev/null | grep -i versionName | head -n 1 | sed 's/.*=//' | tr -d ' \r\n')
            [ -z "$DUMP_VER" ] && DUMP_VER=$(dumpsys package com.gogotv 2>/dev/null | grep -i versionName | head -n 1 | sed 's/.*=//' | tr -d ' \r\n')
            INSTALLED_VER="$DUMP_VER"
        fi
    elif [ "$PKG_ID" = "launcher-patched" ]; then
        [ -f "$PANEL_DIR/.ver_launcher-patched" ] && INSTALLED_VER=$(cat "$PANEL_DIR/.ver_launcher-patched" | tr -d ' \r\n')
    elif [ -f "$PANEL_DIR/.ver_$PKG_ID" ]; then
        INSTALLED_VER=$(cat "$PANEL_DIR/.ver_$PKG_ID" | tr -d ' \r\n')
    fi
    
    # If installed and there is an update available
    if [ -n "$INSTALLED_VER" ] && [ "$REMOTE_VER" != "$INSTALLED_VER" ]; then
        echo "$NOW" > "$LAST_FILE"
        am start -f 0x10000000 -n com.icono.tvoverlay/.OverlayActivity \
            --es title "تحديث متوفر: $PKG_TITLE" \
            --es message "يتوفر إصدار جديد ($REMOTE_VER) لـ $PKG_TITLE! يمكنك التحديث الآن عبر تطبيق الهاتف أو المتجر." \
            --es icon "🚀" \
            --es color "#FF9800" \
            --ei duration 12 > /dev/null 2>&1
        exit 0
    fi
}

# Run checks in priority order:
check_and_notify "mytvonline" "تطبيق MyTVOnline"
check_and_notify "orcagold" "سيرفر OrcaGold"
check_and_notify "panel-update" "لوحة المتجر (Store Panel)"
check_and_notify "launcher-patched" "اللانشر المعدل (Patched Launcher)"
check_and_notify "channels-waleed" "ملف القنوات (Waleed)"
check_and_notify "icam-singlepress" "ICAM Single-Press"
check_and_notify "iquran" "تطبيق القرآن الكريم (iQuran)"
