#!/system/bin/sh
export PATH=/system/bin:/system/xbin:/vendor/bin:/sbin:$PATH
PID_FILE="/tmp/sub_player.pid"
RUN_FLAG="/tmp/sub_player.run"
QUEUE="/tmp/sub_play.queue"
CHANNEL_LOCK="/tmp/sub_channel.lock"
CHANNELS_DIR="/data/plugin/subsync/channels"
SQLITE="/data/plugin/subsync/sqlite3"

case "$1" in
  stop)
    rm -f "$RUN_FLAG" "$QUEUE" "$CHANNEL_LOCK"
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE" 2>/dev/null)
        [ -n "$PID" ] && kill -9 "$PID" 2>/dev/null
    fi
    busybox pkill -9 -f player_runner 2>/dev/null
    busybox pkill -9 -f "busybox sleep" 2>/dev/null
    busybox pkill -9 -f subsync.sh 2>/dev/null
    rm -f "$PID_FILE" /tmp/cur_play.srt
    /system/bin/am startservice -n com.icono.tvoverlay/.ClockOverlayService -a com.icono.tvoverlay.CLEAR_SUBTITLE >/dev/null 2>&1
    echo "STOPPED"
    ;;
  status)
    if [ -f "$RUN_FLAG" ] && [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE" 2>/dev/null)
        if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
            echo "RUNNING"
            exit 0
        fi
    fi
    echo "STOPPED"
    ;;
  play|start)
    $0 stop >/dev/null 2>&1
    busybox sleep 0.1
    
    ARG2="$2"
    ARG3="$3"
    ARG4="$4"
    
    SRT_FILE=""
    OFFSET=0
    SVC_ID=""
    TS_ID=""
    
    if [ -n "$ARG2" ] && [ -f "$ARG2" ] && [ -s "$ARG2" ]; then
        SRT_FILE="$ARG2"
        OFFSET="${ARG3:-0}"
    else
        OFFSET="${ARG2:-0}"
        SVC_ID="$ARG3"
        TS_ID="$ARG4"
    fi
    
    if [ -z "$SRT_FILE" ] && [ -n "$SVC_ID" ]; then
        CH_SRT="$CHANNELS_DIR/ch_${SVC_ID}_${TS_ID:-0}.srt"
        if [ -f "$CH_SRT" ] && [ -s "$CH_SRT" ]; then
            SRT_FILE="$CH_SRT"
        fi
    fi
    
    CUR_SVC=0
    CUR_IDX=0
    if [ -f /tmp/cursvc.tmp ]; then
        CUR_SVC=$(busybox hexdump -s 20 -n 2 -e '1/2 "%u"' /tmp/cursvc.tmp 2>/dev/null)
        CUR_IDX=$(busybox hexdump -s 8 -n 2 -e '1/2 "%u"' /tmp/cursvc.tmp 2>/dev/null)
    fi
    
    if [ -z "$SRT_FILE" ]; then
        CUR_TS=0
        if [ -n "$CUR_IDX" ] && [ -x "$SQLITE" ]; then
            CUR_TS=$($SQLITE /data/db/service.db "SELECT COALESCE(t.tp_ts_id, 0) FROM _svcInfo s LEFT JOIN _tpInfo t ON s.svc_tp_index=t.id WHERE s.svc_idx=$CUR_IDX LIMIT 1;" 2>/dev/null)
        fi
        CH_SRT="$CHANNELS_DIR/ch_${CUR_SVC:-0}_${CUR_TS:-0}.srt"
        if [ -f "$CH_SRT" ] && [ -s "$CH_SRT" ]; then
            SRT_FILE="$CH_SRT"
        elif [ -f "/data/plugin/subsync/current_movie.srt" ] && [ -s "/data/plugin/subsync/current_movie.srt" ]; then
            SRT_FILE="/data/plugin/subsync/current_movie.srt"
        elif [ -f "/data/plugin/subsync/current.srt" ] && [ -s "/data/plugin/subsync/current.srt" ]; then
            SRT_FILE="/data/plugin/subsync/current.srt"
        fi
    fi
    
    if [ -z "$SRT_FILE" ] || [ ! -f "$SRT_FILE" ] || [ ! -s "$SRT_FILE" ]; then
        echo "NOT_FOUND"
        exit 1
    fi
    
    busybox tr -d "\r" < "$SRT_FILE" > /tmp/cur_play.srt
    busybox awk -f /data/plugin/subsync/srt_parser.awk -v offset="${OFFSET:-0}" /tmp/cur_play.srt > "$QUEUE"
    rm -f /tmp/cur_play.srt
    
    touch "$RUN_FLAG"
    
    LOCK_SVC="${SVC_ID:-$CUR_SVC}"
    LOCK_IDX="${CUR_IDX:-0}"
    echo "${LOCK_SVC:-0}:${LOCK_IDX:-0}" > "$CHANNEL_LOCK"
    
    /system/bin/sh /data/plugin/subsync/player_runner.sh "${LOCK_SVC:-0}" "${LOCK_IDX:-0}" </dev/null >/dev/null 2>&1 &
    echo "$!" > "$PID_FILE"
    echo "PLAYING"
    ;;
esac
