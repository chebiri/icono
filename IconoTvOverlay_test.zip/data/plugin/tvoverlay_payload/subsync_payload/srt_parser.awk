function to_sec(t, a) {
    split(t, a, /[:,]/);
    return a[1]*3600 + a[2]*60 + a[3] + a[4]/1000.0;
}
BEGIN {
    cur_t = offset > 0 ? offset : 0;
}
/-->/ {
    s_sec = to_sec($1);
    e_sec = to_sec($3);
    txt = "";
    while ((getline line) > 0) {
        sub(/\r$/, "", line);
        if (line ~ /^[ \t]*$/) break;
        if (txt != "") txt = txt "~~NL~~" line;
        else txt = line;
    }
    if (offset > 0 && e_sec < offset) next;
    if (s_sec < cur_t) {
        wait_t = 0;
        dur_ms = int((e_sec - cur_t) * 1000);
    } else {
        wait_t = s_sec - cur_t;
        dur_ms = int((e_sec - s_sec) * 1000);
        cur_t = s_sec;
    }
    if (dur_ms <= 0) dur_ms = 1500;
    print wait_t "\t" dur_ms "\t" txt;
}
