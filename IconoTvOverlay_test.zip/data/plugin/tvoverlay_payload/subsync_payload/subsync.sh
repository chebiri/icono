#!/system/bin/sh
export PATH=/system/bin:/system/xbin:/vendor/bin:/sbin:$PATH
CONF="/data/plugin/subsync/subsync.conf"
[ -f "$CONF" ] && . "$CONF"

CMD="$1"

case "$CMD" in
    play)
        exec /data/plugin/subsync/sub_player.sh play "$2" "$3" "$4"
        ;;
    stop)
        exec /data/plugin/subsync/sub_player.sh stop
        ;;
    status)
        exec /data/plugin/subsync/sub_player.sh status
        ;;
    show)
        TEXT="$2"
        DUR="${3:-4500}"
        [ -z "$TEXT" ] && exit 0
        B64=$(echo -n "$TEXT" | busybox base64 | busybox tr -d '\r\n')
        /system/bin/am startservice -n com.icono.tvoverlay/.ClockOverlayService \
            -a com.icono.tvoverlay.SUBTITLE \
            --es b64 "$B64" \
            --ei duration_ms "$DUR" \
            --ei dur "$DUR" \
            --es color "${FONT_COLOR:-#FFF275}" \
            --ei size "${FONT_SIZE:-34}" \
            --ei pos_y "${POS_Y:-65}" \
            --es style "${STYLE:-pill}" \
            --es bg_color "${BG_COLOR:-#000000}" \
            --ei bg_alpha "${BG_ALPHA:-165}" \
            --es border_color "${BORDER_COLOR:-none}" \
            --ei border_width "${BORDER_WIDTH:-0}" \
            --ei corner_radius "${CORNER_RADIUS:-18}" \
            --es font "${FONT:-naskh_bold}" \
            --es custom_font "${CUSTOM_FONT:-none}" \
            --ei line_spacing "${LINE_SPACING:-6}" \
            --ei stretch_percent "${STRETCH_PERCENT:-92}" >/dev/null 2>&1
        ;;
    show_b64)
        B64="$2"
        DUR="${3:-4500}"
        [ -z "$B64" ] && exit 0
        /system/bin/am startservice -n com.icono.tvoverlay/.ClockOverlayService \
            -a com.icono.tvoverlay.SUBTITLE \
            --es b64 "$B64" \
            --ei duration_ms "$DUR" \
            --ei dur "$DUR" \
            --es color "${FONT_COLOR:-#FFF275}" \
            --ei size "${FONT_SIZE:-34}" \
            --ei pos_y "${POS_Y:-65}" \
            --es style "${STYLE:-pill}" \
            --es bg_color "${BG_COLOR:-#000000}" \
            --ei bg_alpha "${BG_ALPHA:-165}" \
            --es border_color "${BORDER_COLOR:-none}" \
            --ei border_width "${BORDER_WIDTH:-0}" \
            --ei corner_radius "${CORNER_RADIUS:-18}" \
            --es font "${FONT:-naskh_bold}" \
            --es custom_font "${CUSTOM_FONT:-none}" \
            --ei line_spacing "${LINE_SPACING:-6}" \
            --ei stretch_percent "${STRETCH_PERCENT:-92}" >/dev/null 2>&1
        ;;
    clear)
        /system/bin/am startservice -n com.icono.tvoverlay/.ClockOverlayService -a com.icono.tvoverlay.CLEAR_SUBTITLE >/dev/null 2>&1
        ;;
    movie_card)
        TITLE="$2"
        POSTER="$3"
        YEAR="$4"
        RATING="$5"
        GENRE="$6"
        ACTORS="$7"
        PLOT="$8"
        DUR="${9:-20}"
        POS="${10:-top-right}"
        TRAILER="${11:-}"
        
        /system/bin/am startservice -n com.icono.tvoverlay/.ClockOverlayService \
            -a com.icono.tvoverlay.MOVIE_CARD \
            --es title "$TITLE" \
            --es poster_path "$POSTER" \
            --es poster_url "$POSTER" \
            --es qr_path "/data/plugin/subsync/trailer_qr.png" \
            --es year "$YEAR" \
            --es rating "$RATING" \
            --es genre "$GENRE" \
            --es actors "$ACTORS" \
            --es plot "$PLOT" \
            --ei duration_sec "$DUR" \
            --es pos "$POS" >/dev/null 2>&1
        ;;
    close_card)
        /system/bin/am startservice -n com.icono.tvoverlay/.ClockOverlayService -a com.icono.tvoverlay.CLOSE_MOVIE_CARD >/dev/null 2>&1
        ;;
    config)
        [ -n "$2" ] && FONT_SIZE="$2"
        [ -n "$3" ] && FONT_COLOR="$3"
        [ -n "$4" ] && POS_Y="$4"
        [ -n "$5" ] && STYLE="$5"
        [ -n "$6" ] && BG_COLOR="$6"
        [ -n "$7" ] && BG_ALPHA="$7"
        [ -n "$8" ] && BORDER_COLOR="$8"
        [ -n "$9" ] && BORDER_WIDTH="$9"
        [ -n "${10}" ] && CORNER_RADIUS="${10}"
        [ -n "${11}" ] && FONT="${11}"
        [ -n "${12}" ] && CUSTOM_FONT="${12}"
        [ -n "${13}" ] && DELAY_OFFSET="${13}"
        [ -n "${14}" ] && LINE_SPACING="${14}"
        [ -n "${15}" ] && STRETCH_PERCENT="${15}"

        echo "FONT_SIZE=\"${FONT_SIZE:-34}\"" > "$CONF"
        echo "FONT_COLOR=\"${FONT_COLOR:-#FFF275}\"" >> "$CONF"
        echo "POS_Y=\"${POS_Y:-65}\"" >> "$CONF"
        echo "STYLE=\"${STYLE:-pill}\"" >> "$CONF"
        echo "BG_COLOR=\"${BG_COLOR:-#000000}\"" >> "$CONF"
        echo "BG_ALPHA=\"${BG_ALPHA:-165}\"" >> "$CONF"
        echo "BORDER_COLOR=\"${BORDER_COLOR:-none}\"" >> "$CONF"
        echo "BORDER_WIDTH=\"${BORDER_WIDTH:-0}\"" >> "$CONF"
        echo "CORNER_RADIUS=\"${CORNER_RADIUS:-18}\"" >> "$CONF"
        echo "FONT=\"${FONT:-naskh_bold}\"" >> "$CONF"
        echo "CUSTOM_FONT=\"${CUSTOM_FONT:-}\"" >> "$CONF"
        echo "DELAY_OFFSET=\"${DELAY_OFFSET:-0}\"" >> "$CONF"
        echo "LINE_SPACING=\"${LINE_SPACING:-6}\"" >> "$CONF"
        echo "STRETCH_PERCENT=\"${STRETCH_PERCENT:-92}\"" >> "$CONF"
        ;;
esac
