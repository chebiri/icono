#!/system/bin/sh
export PATH=/system/bin:/system/xbin:/vendor/bin:/sbin:$PATH
CONF="/data/plugin/subsync/subsync.conf"
[ -f "$CONF" ] && . "$CONF"

QUEUE="/tmp/sub_play.queue"
RUN_FLAG="/tmp/sub_player.run"
PID_FILE="/tmp/sub_player.pid"
CHANNEL_LOCK="/tmp/sub_channel.lock"

echo "$$" > "$PID_FILE"

START_SVC="${1:-0}"
START_IDX="${2:-0}"

# If not set from args, read from lock file or current channel
if [ -z "$START_SVC" ] || [ "$START_SVC" = "0" ]; then
    if [ -f "$CHANNEL_LOCK" ]; then
        L_VAL=$(cat "$CHANNEL_LOCK" 2>/dev/null)
        START_SVC=$(echo "$L_VAL" | cut -d: -f1)
        START_IDX=$(echo "$L_VAL" | cut -d: -f2)
    fi
fi

if [ -z "$START_SVC" ] || [ "$START_SVC" = "0" ]; then
    if [ -f /tmp/cursvc.tmp ]; then
        START_SVC=$(busybox hexdump -s 20 -n 2 -e '1/2 "%u"' /tmp/cursvc.tmp 2>/dev/null)
        START_IDX=$(busybox hexdump -s 8 -n 2 -e '1/2 "%u"' /tmp/cursvc.tmp 2>/dev/null)
    fi
fi

is_channel_changed() {
    [ -z "$START_SVC" ] && return 1
    if [ -f /tmp/cursvc.tmp ]; then
        NOW_SVC=$(busybox hexdump -s 20 -n 2 -e '1/2 "%u"' /tmp/cursvc.tmp 2>/dev/null)
        NOW_IDX=$(busybox hexdump -s 8 -n 2 -e '1/2 "%u"' /tmp/cursvc.tmp 2>/dev/null)
        if [ -n "$NOW_SVC" ]; then
            if [ "$NOW_SVC" != "$START_SVC" ]; then
                return 0
            fi
            if [ -n "$START_IDX" ] && [ -n "$NOW_IDX" ]; then
                if [ "$NOW_IDX" != "$START_IDX" ]; then
                    return 0
                fi
            fi
        fi
    fi
    return 1
}

responsive_sleep() {
    W_SEC="$1"
    [ -z "$W_SEC" ] && return 0
    
    REMAIN="$W_SEC"
    while [ -f "$RUN_FLAG" ]; do
        if is_channel_changed; then
            rm -f "$RUN_FLAG"
            return 1
        fi
        
        # Check if remaining <= 0.4s
        IS_LAST=$(echo "$REMAIN" | busybox awk '{if ($1 <= 0.4) print 1; else print 0}')
        if [ "$IS_LAST" = "1" ]; then
            IS_POS=$(echo "$REMAIN" | busybox awk '{if ($1 > 0.03) print 1; else print 0}')
            [ "$IS_POS" = "1" ] && busybox sleep "$REMAIN"
            break
        fi
        
        busybox sleep 0.4
        REMAIN=$(echo "$REMAIN" | busybox awk '{val = $1 - 0.4; if (val < 0) val = 0; print val}')
    done
    
    if is_channel_changed; then
        rm -f "$RUN_FLAG"
        return 1
    fi
    return 0
}

while IFS="$(printf '\t')" read -r wait_t dur_ms txt || [ -n "$txt" ]; do
    [ ! -f "$RUN_FLAG" ] && break
    [ -z "$txt" ] && continue
    
    # Check if channel changed before waiting
    if is_channel_changed; then
        break
    fi
    
    if [ -n "$wait_t" ]; then
        IS_WAIT=$(echo "$wait_t" | busybox awk '{if ($1 > 0.05) print 1; else print 0}')
        if [ "$IS_WAIT" = "1" ]; then
            if ! responsive_sleep "$wait_t"; then
                break
            fi
            [ ! -f "$RUN_FLAG" ] && break
        fi
    fi
    
    # Check if channel changed right before displaying
    if is_channel_changed; then
        break
    fi
    
    CLEAN_TXT=$(echo "$txt" | busybox awk '{gsub("~~NL~~", "\n"); print}')
    B64=$(echo -n "$CLEAN_TXT" | busybox base64 | busybox tr -d '\r\n')
    [ -z "$B64" ] && continue
    
    /system/bin/am startservice -n com.icono.tvoverlay/.ClockOverlayService \
        -a com.icono.tvoverlay.SUBTITLE \
        --es b64 "$B64" \
        --es color "${FONT_COLOR:-#FFF275}" \
        --ei size "${FONT_SIZE:-34}" \
        --ei pos_y "${POS_Y:-65}" \
        --ei duration_ms "${dur_ms:-4500}" \
        --es style "${STYLE:-pill}" \
        --es bg_color "${BG_COLOR:-#000000}" \
        --ei bg_alpha "${BG_ALPHA:-165}" \
        --es border_color "${BORDER_COLOR:-none}" \
        --ei border_width "${BORDER_WIDTH:-0}" \
        --ei corner_radius "${CORNER_RADIUS:-18}" \
        --es font "${FONT:-naskh_bold}" \
        --es custom_font "${CUSTOM_FONT:-}" \
        --ei line_spacing "${LINE_SPACING:-6}" \
        --ei stretch_percent "${STRETCH_PERCENT:-92}" >/dev/null 2>&1
done < "$QUEUE"

# Cleanup immediately on exit
rm -f "$RUN_FLAG" "$PID_FILE" "$QUEUE" "$CHANNEL_LOCK"
/system/bin/am startservice -n com.icono.tvoverlay/.ClockOverlayService -a com.icono.tvoverlay.CLEAR_SUBTITLE >/dev/null 2>&1
